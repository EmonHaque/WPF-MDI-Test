﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace MDITest
{
    class TopWindow : Window
    {
        public TopWindow() {
            Title = "Top";
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            WindowStyle = WindowStyle.None;
            //SnapsToDevicePixels = true;
            ShowInTaskbar = false;
        }
    }
}
