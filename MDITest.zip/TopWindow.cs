﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MDITest
{
    class TopWindow : Window
    {
        public TopWindow() {
            Title = "Top";
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            WindowStyle = WindowStyle.None;
            ShowInTaskbar = false;
        }
    }
}
