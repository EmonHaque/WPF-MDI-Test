﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Shell;

namespace MDITest
{
    class RootWindow : Window
    {
        double radius = 5;
        Border windowBorder, titleBar;
        Grid contentGrid, titlebarIconGrid, rectGrid;
        ActionButton close, minimize, maxRestore;
        Rectangle topRect, midRect, botRect;
        public TopWindow TopWin { get; set; }
        public MiddleWindow MidWin { get; set; }
        public BottomWindow BotWin { get; set; }
        public RootWindow() {
            Height = 800;
            Width = 1200;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            WindowChrome.SetWindowChrome(this, new WindowChrome() {
                ResizeBorderThickness = new Thickness(0, 0, 5, 5),
                CaptionHeight = 0
            });
            addTitleIcons();
            titleBar = new Border() {
                CornerRadius = new CornerRadius(radius, radius, 0, 0),
                Background = Brushes.LightGray,
                Height = 32,
                Effect = new DropShadowEffect() { BlurRadius = 5, Opacity = 0.5, Direction = -90 },
                Child = titlebarIconGrid
            };
            initRects();
            Grid.SetRow(rectGrid, 1);
            contentGrid = new Grid() {
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { titleBar, rectGrid }
            };
            windowBorder = new Border() {
                Background = Brushes.Transparent,
                CornerRadius = new CornerRadius(radius),
                BorderThickness = new Thickness(1),
                BorderBrush = Brushes.LightBlue,
                Child = contentGrid
            };
            AddVisualChild(windowBorder);
            titleBar.MouseLeftButtonDown += handleResize;
            titleBar.MouseMove += move;
            Loaded += onLoaded;
            StateChanged += onStateChanged;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            TopWin.Dispatcher.Invoke(() => {
                TopWin.Content = new TestContent("Top Window");
                TopWin.Show();

            });
            MidWin.Dispatcher.Invoke(() => {
                MidWin.Content = new TestContent("Mid Window");
                MidWin.Show();
            });
            BotWin.Dispatcher.Invoke(() => {
                BotWin.Content = new TestContent("Bot Window");
                BotWin.Show();
            });
        }
        void onStateChanged(object sender, EventArgs e) {
            if(WindowState == WindowState.Minimized) {
                TopWin.Dispatcher.Invoke(TopWin.Hide);
                MidWin.Dispatcher.Invoke(MidWin.Hide);
                BotWin.Dispatcher.Invoke(BotWin.Hide);
            }
            else {
                TopWin.Dispatcher.Invoke(() => {
                    TopWin.Show();
                    TopWin.Activate();
                });
                MidWin.Dispatcher.Invoke(() => {
                    MidWin.Show();
                    MidWin.Activate();
                });
                BotWin.Dispatcher.Invoke(() => {
                    BotWin.Show();
                    BotWin.Activate();
                });
            }
        }  
        void initRects() {
            topRect = new Rectangle()/* { SnapsToDevicePixels = true }*/;
            midRect = new Rectangle()/* { SnapsToDevicePixels = true }*/;
            botRect = new Rectangle()/* { SnapsToDevicePixels = true }*/;
            Grid.SetRow(midRect, 1);
            Grid.SetRow(botRect, 2);
            rectGrid = new Grid() {
                //SnapsToDevicePixels = true,
                RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(),
                    new RowDefinition()
                },
                Children = { topRect, midRect, botRect }
            };
        }
        void move(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) {
                DragMove();
                resizeOthers();
            }
        }
        void resizeOthers() {
            double width = topRect.ActualWidth;
            double height = topRect.ActualHeight;

            var topPoint = topRect.PointToScreen(new Point(0, 0));
            var midPoint = midRect.PointToScreen(new Point(0, 0));
            var botPoint = botRect.PointToScreen(new Point(0, 0));
            TopWin.Dispatcher.Invoke(() => {
                TopWin.Left = topPoint.X;
                TopWin.Top = topPoint.Y;
                TopWin.Width = width;
                TopWin.Height = height;
            });
            MidWin.Dispatcher.Invoke(() => {
                MidWin.Left = midPoint.X;
                MidWin.Top = midPoint.Y;
                MidWin.Width = width;
                MidWin.Height = height;
            });
            BotWin.Dispatcher.Invoke(() => {
                BotWin.Left = botPoint.X;
                BotWin.Top = botPoint.Y;
                BotWin.Width = width;
                BotWin.Height = height;
            });
        }
        void handleResize(object sender, MouseButtonEventArgs e) {
            if (e.ClickCount == 2) resize();
        }
        void addTitleIcons() {
            close = new ActionButton() {
                Width = 24,
                Height = 24,
                ToolTip = "Close",
                Margin = new Thickness(0, 0, 5, 0),
                Icon = Icons.CloseCircle,
                Command = Application.Current.Shutdown
            };
            maxRestore = new ActionButton() {
                Width = 18,
                Height = 18,
                ToolTip = "Maximize",
                Margin = new Thickness(0, 0, 5, 0),
                Icon = Icons.Maximize,
                Command = resize
            };
            minimize = new ActionButton() {
                Width = 18,
                Height = 18,
                ToolTip = "Minimize",
                Margin = new Thickness(0, 0, 5, 0),
                Icon = Icons.Minimize,
                Command = () => WindowState = WindowState.Minimized
            };
            Grid.SetColumn(close, 3);
            Grid.SetColumn(maxRestore, 2);
            Grid.SetColumn(minimize, 1);
            titlebarIconGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { close, maxRestore, minimize }
            };
        }
        void resize() {
            if (WindowState == WindowState.Maximized) {
                ResizeMode = ResizeMode.CanResizeWithGrip;
                WindowState = WindowState.Normal;
                maxRestore.Icon = Icons.Maximize;
                maxRestore.ToolTip = "Maximize";
            }
            else {
                ResizeMode = ResizeMode.NoResize;
                WindowState = WindowState.Maximized;
                maxRestore.Icon = Icons.Restore;
                maxRestore.ToolTip = "Restore";
            }
        }
        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) => resizeOthers();
        protected override void OnClosing(CancelEventArgs e) {
            titleBar.MouseLeftButtonDown -= handleResize;
            titleBar.MouseMove -= move;
        }
        protected override void OnClosed(EventArgs e) {
            TopWin.Dispatcher.Invoke(TopWin.Close);
            MidWin.Dispatcher.Invoke(MidWin.Close);
            BotWin.Dispatcher.Invoke(BotWin.Close);
            TopWin.Dispatcher.InvokeShutdown();
            MidWin.Dispatcher.InvokeShutdown();
            BotWin.Dispatcher.InvokeShutdown();
            App.Current.Shutdown();
        }
        protected override Visual GetVisualChild(int index) => windowBorder;
        protected override int VisualChildrenCount => 1;
    }
}
