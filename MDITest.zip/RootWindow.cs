﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Shell;

namespace MDITest
{
    class RootWindow : Window
    {
        double radius = 5;
        Border windowBorder, titleBar;
        Grid contentGrid, titlebarIconGrid;
        ActionButton close, minimize, maxRestore;
        public TopWindow TopWin { get; set; }
        public MiddleWindow MidWin { get; set; }
        public BottomWindow BotWin { get; set; }
        public RootWindow() {
            Height = 800;
            Width = 1200;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            WindowChrome.SetWindowChrome(this, new WindowChrome() {
                ResizeBorderThickness = new Thickness(0, 0, 5, 5),
                CaptionHeight = 0
            });
            addTitleIcons();
            titleBar = new Border() {
                CornerRadius = new CornerRadius(radius, radius, 0, 0),
                Background = Brushes.LightGray,
                Height = 32,
                Effect = new DropShadowEffect() { BlurRadius = 5, Opacity = 0.5, Direction = -90 },
                Child = titlebarIconGrid
            };
            contentGrid = new Grid() {
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { titleBar }
            };
            windowBorder = new Border() {
                Background = Brushes.Transparent,
                CornerRadius = new CornerRadius(radius),
                BorderThickness = new Thickness(1),
                BorderBrush = Brushes.LightBlue,
                Child = contentGrid
            };
            AddVisualChild(windowBorder);
            titleBar.MouseLeftButtonDown += handleResize;
            titleBar.MouseMove += move;
            Loaded += onLoaded;
        }
        void onLoaded(object sender, RoutedEventArgs e) {
            TopWin.Dispatcher.Invoke(() => {
                TopWin.Content = new TestContent("Top Window");
                TopWin.Show();

            });
            MidWin.Dispatcher.Invoke(() => {
                MidWin.Content = new TestContent("Mid Window");
                MidWin.Show();
            });
            BotWin.Dispatcher.Invoke(() => {
                BotWin.Content = new TestContent("Bot Window");
                BotWin.Show();
            });
        }
        void move(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) {
                DragMove();
                resizeOthers();
            }
        }
        void resizeOthers() {
            var position = contentGrid.PointToScreen(new Point(0, 0));
            double width = contentGrid.ActualWidth;
            double height = (contentGrid.ActualHeight - titleBar.ActualHeight) / 3;
            double x = position.X;
            double y = position.Y + titleBar.ActualHeight;
            TopWin.Dispatcher.Invoke(() => {
                TopWin.Left = x;
                TopWin.Top = y;
                TopWin.Width = width;
                TopWin.Height = height;
            });
            y += height;
            MidWin.Dispatcher.Invoke(() => {
                MidWin.Left = x;
                MidWin.Top = y;
                MidWin.Width = width;
                MidWin.Height = height;
            });
            y += height;
            BotWin.Dispatcher.Invoke(() => {
                BotWin.Left = x;
                BotWin.Top = y;
                BotWin.Width = width;
                BotWin.Height = height;
            });
        }
        void handleResize(object sender, MouseButtonEventArgs e) {
            if (e.ClickCount == 2) resize();
        }
        void addTitleIcons() {
            close = new ActionButton() {
                Width = 24,
                Height = 24,
                ToolTip = "Close",
                Margin = new Thickness(0, 0, 5, 0),
                Icon = Icons.CloseCircle,
                Command = Application.Current.Shutdown
            };
            maxRestore = new ActionButton() {
                Width = 18,
                Height = 18,
                ToolTip = "Maximize",
                Margin = new Thickness(0, 0, 5, 0),
                Icon = Icons.Maximize,
                Command = resize
            };
            minimize = new ActionButton() {
                Width = 18,
                Height = 18,
                ToolTip = "Minimize",
                Margin = new Thickness(0, 0, 5, 0),
                Icon = Icons.Minimize,
                Command = () => WindowState = WindowState.Minimized
            };
            Grid.SetColumn(close, 3);
            Grid.SetColumn(maxRestore, 2);
            Grid.SetColumn(minimize, 1);
            titlebarIconGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { close, maxRestore, minimize }
            };
        }
        void resize() {
            if (WindowState == WindowState.Maximized) {
                ResizeMode = ResizeMode.CanResizeWithGrip;
                WindowState = WindowState.Normal;
                maxRestore.Icon = Icons.Maximize;
                maxRestore.ToolTip = "Maximize";
            }
            else {
                ResizeMode = ResizeMode.NoResize;
                WindowState = WindowState.Maximized;
                maxRestore.Icon = Icons.Restore;
                maxRestore.ToolTip = "Restore";
            }
        }        
        protected override void OnStateChanged(EventArgs e) {
            if (WindowState == WindowState.Minimized) {
                TopWin.Dispatcher.Invoke(TopWin.Hide);
                MidWin.Dispatcher.Invoke(MidWin.Hide);
                BotWin.Dispatcher.Invoke(BotWin.Hide);
            }
            else {
                TopWin.Dispatcher.Invoke(() => {
                    TopWin.Show();
                    TopWin.Activate();
                });
                MidWin.Dispatcher.Invoke(() => {
                    MidWin.Show();
                    MidWin.Activate();
                });
                BotWin.Dispatcher.Invoke(() => {
                    BotWin.Show();
                    BotWin.Activate();
                });
            }
        }
        protected override void OnActivated(EventArgs e) {
            TopWin.Dispatcher.Invoke(TopWin.Show);
            MidWin.Dispatcher.Invoke(MidWin.Show);
            BotWin.Dispatcher.Invoke(BotWin.Show);
            Activate();
        }
        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) => resizeOthers();
        protected override void OnClosing(CancelEventArgs e) {
            Loaded -= onLoaded;
            titleBar.MouseLeftButtonDown -= handleResize;
            titleBar.MouseMove -= move;
            TopWin.Dispatcher.Invoke(TopWin.Close);
            MidWin.Dispatcher.Invoke(MidWin.Close);
            BotWin.Dispatcher.Invoke(BotWin.Close);
        }
        protected override void OnClosed(EventArgs e) {       
            TopWin.Dispatcher.InvokeShutdown();
            MidWin.Dispatcher.InvokeShutdown();
            BotWin.Dispatcher.InvokeShutdown();
            App.Current.Shutdown();
        }
        protected override Visual GetVisualChild(int index) => windowBorder;
        protected override int VisualChildrenCount => 1;
    }
}
