﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace MDITest
{
    class TestContent : StackPanel
    {
        public TestContent(string text) {
            HorizontalAlignment = HorizontalAlignment.Center;
            VerticalAlignment = VerticalAlignment.Center;
            Children.Add(new TextBlock() {
                Text = text,
                FontSize = 36
            });
            var button = new Button() {
                Margin = new Thickness(20),
                FontSize = 26,
                Content = "Click"
            };
            button.Click += (s, e) => MessageBox.Show(text + " Clicked");
            Children.Add(button);
        }
    }
}
