﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace MDITest
{
    class BottomWindow : Window
    {
        public BottomWindow() {
            Title = "Bottom";
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            //SnapsToDevicePixels = true;
            WindowStyle = WindowStyle.None;
            ShowInTaskbar = false;
        }
    }
}
