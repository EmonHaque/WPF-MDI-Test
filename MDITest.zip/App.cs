﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace MDITest
{
    class App : Application
    {
        [STAThread]
        static void Main() => new App().Run();
        protected override void OnStartup(StartupEventArgs e) {
            TopWindow top = null;
            MiddleWindow mid = null;
            BottomWindow bot = null;
            var thread1 = new Thread(() => { 
                top = new TopWindow(); 
                Dispatcher.Run(); 
            });
            var thread2 = new Thread(() => { 
                mid = new MiddleWindow(); 
                Dispatcher.Run(); 
            });
            var thread3 = new Thread(() => { 
                bot = new BottomWindow(); 
                Dispatcher.Run(); 
            });
            thread1.SetApartmentState(ApartmentState.STA);
            thread2.SetApartmentState(ApartmentState.STA);
            thread3.SetApartmentState(ApartmentState.STA);
            thread1.Start();
            thread2.Start();
            thread3.Start();
            App.Current.MainWindow = new RootWindow() {
                TopWin = top,
                MidWin = mid,
                BotWin = bot
            };
            App.Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            App.Current.MainWindow.Show();
        }
    }
}
